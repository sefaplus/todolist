import TodoListApp from "./components/TodoListApp";
import ReactDOM from "react-dom/client"

function App() {
  return <TodoListApp />;
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
