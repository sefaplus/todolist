export default function TodoItem({value, onTodoChange}) {

  const {task, status} = value;

  
    // function handleTaskStatus(e) {
    //   let Id = e.target.value;
    //   let targetStatus = e.target.checked;
    //   tasks[Id].status = targetStatus;
    // }
  
    function handleTodoChange(e) {
      onTodoChange({task: e.target.value})
    }
  
    // function handleLiDblClick(e) {
    //   e.target.readOnly = false;
    //   e.target.addEventListener("keypress", (e) => {
    //     if (e.key === "Enter") {
    //       console.log(document.getSelection().anchorNode);
    //     }
    //   });
    // }
  
    return (
      <li>
        <input
          type="text"
          onChange={handleTodoChange}
          className="todolist-task"
          value={task}
        />
        <input
          type="checkbox"
          value={status}
          // onChange={handleTaskStatus}
        />
      </li>
    );
  }