import { useState } from "react";

export default function TodoNameInput({ onClick }) {
    let [addTaskText, setAddTaskText] = useState("");
  
    const handleAddTask = (e) => {
      onClick(addTaskText);
    };
  
    const handleTaskTextChange = (e) => {
      setAddTaskText(e.target.value);
    };
  
    return (
      <>
        <input
          id="add-task"
          type="text"
          value={addTaskText}
          onChange={handleTaskTextChange}
        />
        <button onClick={handleAddTask}>Add</button>
      </>
    );
  }