import { useState } from "react";
import TaskList from "./TodoList";
import TodoNameInput from "./TodoNameInput";

export default function TodoListApp() {
  let [tasks, setTasks] = useState([
    { task: "But groceries", status: true, id: Date.now() },
    { task: "Complete todo list", status: false, id: Date.now() },
    { task: "blablabla", status: false, id: Date.now() },
    { task: "car", status: true, id: Date.now() },
  ]);
  let [filter, setFilter] = useState(0);

  const handleTodoAdd = (todoName) => {
    setTasks((prevTasks) => [...prevTasks, { task: todoName, status: false }]);
  };

  const handleTodoChange = (id) => (updatedTodo) => {
    setTasks((prevTasks) =>
      prevTasks.map((todo, index) =>
        index === id ? { ...todo, ...updatedTodo } : todo
      )
    );
  };

  return (
    <>
      <TodoNameInput onClick={handleTodoAdd} />
      <TaskList tasks={tasks} filter={filter} onTodoChange={handleTodoChange} />
      <div>
        <div className="todo-controls">
          <p> Tasks: {tasks.length} </p>
          <button onClick={() => setFilter(0)}> ALL </button>
          <button onClick={() => setFilter(1)}> Active </button>
          <button onClick={() => setFilter(2)}> Completed </button>
        </div>
      </div>
    </>
  );
}
