import { useState } from "react";
import TodoItem from "./TodoItem";

export default function TaskList({ tasks, filter, onTodoChange }) {
  // let [tasklist, setTaskList] = useState([]);
  let [tempText, setTempText] = useState("");

  // useEffect(() => {
  //   let tempArray = [];
  //   tasks.forEach((task, index) => {
  //     switch (filter) {
  //       case 0:
  //         tempArray.push(Task(index, task.task, task.status));
  //         break;
  //       case 1:
  //         if (!task.status) {
  //           tempArray.push(Task(index, task.task, task.status));
  //         }
  //         break;
  //       case 2:
  //         if (task.status) {
  //           tempArray.push(Task(index, task.task, task.status));
  //         }
  //         break;
  //     }
  //   });
  //   setTaskList(tempArray);
  // }, [tasks.length, filter]);

  return tasks.map((todoData, id) => (
    <TodoItem key={id} value={todoData} onTodoChange={onTodoChange(id)} />
  ));
}
